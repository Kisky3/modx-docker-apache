<?php
include(MODX_BASE_PATH . 'manager/actions/footer.inc.php');
