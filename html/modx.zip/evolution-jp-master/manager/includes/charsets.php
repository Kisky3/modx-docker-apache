<option value="UTF-8" <?php echo $modx_charset === 'UTF-8' ? "selected='selected'" : ""; ?> >UTF-8</option>
