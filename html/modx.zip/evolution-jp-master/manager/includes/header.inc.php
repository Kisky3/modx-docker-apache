<?php
include(MODX_BASE_PATH . 'manager/actions/header.inc.php');
