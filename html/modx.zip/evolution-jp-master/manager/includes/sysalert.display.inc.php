<?php
$modx->manager->sysAlert();
