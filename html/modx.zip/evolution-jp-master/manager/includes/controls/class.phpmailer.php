<?php
include_once(MODX_CORE_PATH . 'controls/phpmailer/class.phpmailer.php');
