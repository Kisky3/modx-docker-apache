<?php
// Move to $modx->sanitize_gpc();
