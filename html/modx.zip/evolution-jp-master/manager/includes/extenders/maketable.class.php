<?php
include_once MODX_BASE_PATH . 'manager/includes/extenders/ex_maketable.php';
