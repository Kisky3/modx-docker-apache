<?php

// ref:[Zend Framework v1] library/Zend/Locale/Data/*.xml
// https://github.com/zendframework/zf1/tree/master/library/Zend/Locale/Data

$_lc['days.short'] = '日,月,火,水,木,金,土';
$_lc['days.wide']  = '日曜日,月曜日,火曜日,水曜日,木曜日,金曜日,土曜日,';
