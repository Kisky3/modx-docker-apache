<?php
	return include(dirname(__FILE__) . '/date.inc.php');
