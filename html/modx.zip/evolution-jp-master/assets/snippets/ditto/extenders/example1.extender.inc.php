<?php

/*
 * Title: Example1
 * Purpose:
 *  	Example file for basing new Extenders on
*/

// ---------------------------------------------------
// Group: Parameters
// Define any parameters needed in the extender or to override Ditto defaults
// ---------------------------------------------------

$display = isset($display) ? $display : 3;
