<script language="javascript" type="text/javascript" src="[+editor_path+]tiny_mce/tiny_mce_popup.js"></script>
<script language="javascript" type="text/javascript" src="[+editor_path+]tinymce.modxfb.js"></script>
